'use strict';
// Use the same template for the frontend code
require('../tpl/registedTeam.jade');
require('../sass/registedteam.scss');